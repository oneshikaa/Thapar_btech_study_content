echo "Enter two numbers"
read x
read y
sum=`expr $x + $y`
echo "Sum = $sum"